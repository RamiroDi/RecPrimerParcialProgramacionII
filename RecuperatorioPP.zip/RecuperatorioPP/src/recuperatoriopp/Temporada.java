package recuperatoriopp;


public enum Temporada {
    PRIMAVERA,
    VERANO,
    OTONIO,
    INVIERNO
}

