package recuperatoriopp;

import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {
    private List<Planta> plantas;

    public JardinBotanico() {
        this.plantas = new ArrayList<>();
    }

    // Método para agregar una planta
    public void agregarPlanta(Planta planta) throws PlantaExistenteException {
        for (Planta p : plantas) {
            // Verifica si ya existe una planta con el mismo nombre y ubicación
            if (p.getNombre().equals(planta.getNombre()) && p.getUbicacion().equals(planta.getUbicacion())) {
                throw new PlantaExistenteException("Ya existe una planta con el nombre " + planta.getNombre() + 
                                                   " en la ubicacion " + planta.getUbicacion());
            }
        }
        plantas.add(planta);
        System.out.println("Planta " + planta.getNombre() + " agregada exitosamente.");
    }

    // Método para mostrar todas las plantas
    public void mostrarPlantas() {
        if (plantas.isEmpty()) {
            System.out.println("No hay plantas registradas.");
            return;
        }
        for (Planta planta : plantas) {
            System.out.println(planta.toString());
        }
    }

    // Método para podar las plantas (solo árboles y arbustos)
    public void podarPlantas() {
        for (Planta planta : plantas) {
            if (planta instanceof Podable) {
                ((Podable) planta).podar();  // Llama al método podar() de árboles y arbustos
            } else {
                System.out.println("La planta " + planta.getNombre() + " no puede ser podada (es una flor).");
            }
        }
    }
}
