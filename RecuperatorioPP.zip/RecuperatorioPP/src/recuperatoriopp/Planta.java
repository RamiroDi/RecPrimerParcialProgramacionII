package recuperatoriopp;

import java.util.Objects;

public abstract class Planta {
    protected String nombre;
    protected String ubicacion;
    protected String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede ser vacio o nulo.");
        }
        if (ubicacion == null || ubicacion.isEmpty()) {
            throw new IllegalArgumentException("La ubicacion no puede ser vacia o nula.");
        }
        if (clima == null || clima.isEmpty()) {
            throw new IllegalArgumentException("El clima no puede ser vacio o nulo.");
        }
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String getClima() {
        return clima;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Ubicacion: " + ubicacion + ", Clima: " + clima;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Planta planta = (Planta) o;
        return nombre.equals(planta.nombre) && ubicacion.equals(planta.ubicacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }
}
