package recuperatoriopp;

public class PlantaExistenteException extends Exception {
    public PlantaExistenteException(String message) {
        super(message);
    }
}

