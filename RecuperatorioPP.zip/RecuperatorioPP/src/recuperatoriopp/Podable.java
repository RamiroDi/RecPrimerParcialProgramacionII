package recuperatoriopp;


public interface Podable {
    void podar();
}

