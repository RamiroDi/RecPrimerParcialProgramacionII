package recuperatoriopp;

public class TestJardinBotanico {

    public static void main(String[] args) {
        // Crear el jardín botánico
        JardinBotanico jardin = new JardinBotanico();

        try {
            // Crear instancias de diferentes plantas
            Arbol arbol1 = new Arbol("Roble", "Sector A", "Templado", 20.5);
            Arbusto arbusto1 = new Arbusto("Lavanda", "Sector B", "Mediterraneo", 7);
            Flor flor1 = new Flor("Rosa", "Sector C", "Templado", Temporada.PRIMAVERA);

            // Agregar plantas al jardín
            jardin.agregarPlanta(arbol1);
            jardin.agregarPlanta(arbusto1);
            jardin.agregarPlanta(flor1);

            // Intentar agregar una planta duplicada para probar la excepción
            try {
                jardin.agregarPlanta(new Arbol("Roble", "Sector A", "Templado", 25));
            } catch (PlantaExistenteException e) {
                System.out.println(e.getMessage());  // Debería indicar que ya existe la planta en esa ubicación
            }

            // Mostrar todas las plantas en el jardín
            System.out.println("\nListado de plantas en el jardin:");
            jardin.mostrarPlantas();

            // Podar las plantas que pueden ser podadas (árboles y arbustos)
            System.out.println("\nPodando las plantas:");
            jardin.podarPlantas();

        } catch (PlantaExistenteException e) {
            System.out.println("Error al agregar una planta: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Error en la creacion de una planta: " + e.getMessage());
        }
    }
}
