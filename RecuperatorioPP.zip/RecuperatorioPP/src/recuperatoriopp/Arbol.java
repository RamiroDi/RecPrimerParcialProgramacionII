package recuperatoriopp;

public class Arbol extends Planta implements Podable {
    private double alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, double alturaMaxima) {
        super(nombre, ubicacion, clima);
        if (alturaMaxima <= 0) {
            throw new IllegalArgumentException("La altura maxima del arbol debe ser un valor positivo.");
        }
        this.alturaMaxima = alturaMaxima;
    }

    public double getAlturaMaxima() {
        return alturaMaxima;
    }

    public void setAlturaMaxima(double alturaMaxima) {
        if (alturaMaxima <= 0) {
            throw new IllegalArgumentException("La altura maxima del arbol debe ser un valor positivo.");
        }
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public void podar() {
        System.out.println("El arbol " + getNombre() + " ha sido podado.");
    }

    @Override
    public String toString() {
        return super.toString() + ", Altura Maxima: " + alturaMaxima + " metros";
    }
}

